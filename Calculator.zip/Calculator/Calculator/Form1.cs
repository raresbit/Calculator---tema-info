﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Rezultat.scrie == 0)
            {
                Rezultat.scrie = 1;
                textBox1.Text = "";
                textBox1.Text = textBox1.Text + button2.Text;
            }
            else
            {
                textBox1.Text = textBox1.Text + button2.Text;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Rezultat.nr = Convert.ToInt64(textBox1.Text);
            textBox1.Text = "";
            Rezultat.operatie = 1; //setez operatia la impartire
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Rezultat.scrie == 0)
            {
                Rezultat.scrie = 1;
                textBox1.Text = "";
                textBox1.Text = textBox1.Text + button1.Text;
            }
            else
            {
                textBox1.Text = textBox1.Text + button1.Text;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Rezultat.scrie == 0)
            {
                Rezultat.scrie = 1;
                textBox1.Text = "";
                textBox1.Text = textBox1.Text + button3.Text;
            }
            else
            {
                textBox1.Text = textBox1.Text + button3.Text;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (Rezultat.scrie == 0)
            {
                Rezultat.scrie = 1;
                textBox1.Text = "";
                textBox1.Text = textBox1.Text + button10.Text;
            }
            else
            {
                textBox1.Text = textBox1.Text + button10.Text;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (Rezultat.scrie == 0)
            {
                Rezultat.scrie = 1;
                textBox1.Text = "";
                textBox1.Text = textBox1.Text + button9.Text;
            }
            else
            {
                textBox1.Text = textBox1.Text + button9.Text;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (Rezultat.scrie == 0)
            {
                Rezultat.scrie = 1;
                textBox1.Text = "";
                textBox1.Text = textBox1.Text + button8.Text;
            }
            else
            {
                textBox1.Text = textBox1.Text + button8.Text;
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (Rezultat.scrie == 0)
            {
                Rezultat.scrie = 1;
                textBox1.Text = "";
                textBox1.Text = textBox1.Text + button15.Text;
            }
            else
            {
                textBox1.Text = textBox1.Text + button15.Text;
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (Rezultat.scrie == 0)
            {
                Rezultat.scrie = 1;
                textBox1.Text = "";
                textBox1.Text = textBox1.Text + button14.Text;
            }
            else
            {
                textBox1.Text = textBox1.Text + button14.Text;
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (Rezultat.scrie == 0)
            {
                Rezultat.scrie = 1;
                textBox1.Text = "";
                textBox1.Text = textBox1.Text + button13.Text;
            }
            else
            {
                textBox1.Text = textBox1.Text + button13.Text;
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (Rezultat.scrie == 0)
            {
                Rezultat.scrie = 1;
                textBox1.Text = "";
                textBox1.Text = textBox1.Text + button20.Text;
            }
            else
            {
                textBox1.Text = textBox1.Text + button20.Text;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if(Rezultat.operatie == 1) //Daca operatia a fost impartire
            {
                Rezultat.rezultat = Convert.ToDouble(textBox1.Text);
                if (Rezultat.rezultat != 0)
                {
                    Rezultat.rezultat = Rezultat.nr / Rezultat.rezultat;
                    textBox1.Text = Convert.ToString(Rezultat.rezultat);
                }
                else
                {
                    textBox1.Text = "0";
                }
                Rezultat.scrie = 0;
            }else if (Rezultat.operatie == 2) //Daca operatia a fost impartire
            {
                Rezultat.rezultat = Convert.ToDouble(textBox1.Text);
                Rezultat.rezultat = Rezultat.nr * Rezultat.rezultat;
                textBox1.Text = Convert.ToString(Rezultat.rezultat);
                Rezultat.scrie = 0;
            }
            else if (Rezultat.operatie == 3) //Daca operatia a fost impartire
            {
                Rezultat.rezultat = Convert.ToDouble(textBox1.Text);
                Rezultat.rezultat = Rezultat.nr - Rezultat.rezultat;
                textBox1.Text = Convert.ToString(Rezultat.rezultat);
                Rezultat.scrie = 0;
            }
            else if (Rezultat.operatie == 4) //Daca operatia a fost impartire
            {
                Rezultat.rezultat = Convert.ToDouble(textBox1.Text);
                Rezultat.rezultat = Rezultat.nr + Rezultat.rezultat;
                textBox1.Text = Convert.ToString(Rezultat.rezultat);
                Rezultat.scrie = 0;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Rezultat.nr = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "";
            Rezultat.operatie = 2; //setez operatia la inmultire
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Rezultat.nr = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "";
            Rezultat.operatie = 3; //setez operatia la scadere
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Rezultat.nr = Convert.ToDouble(textBox1.Text);
            textBox1.Text = "";
            Rezultat.operatie = 4; //setez operatia la adunare
        }
    }
    static class Rezultat
    {
        public static double nr = 0;

        public static double rezultat = 0;

        public static int operatie = 0; //1 = impartire, 2 = inmultire, 3 = scadere, 4 = adunare

        public static int scrie = 0; // 0 = False, 1 = True
    }
}
